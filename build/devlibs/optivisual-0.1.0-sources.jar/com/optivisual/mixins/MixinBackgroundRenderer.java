package com.optivisual.mixins;

import com.optivisual.config.ConfigManager;
import com.optivisual.config.ConfigData;
import net.minecraft.client.render.BackgroundRenderer;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.Fog;
import net.minecraft.client.render.FogShape;
import net.minecraft.client.world.ClientWorld;
import org.joml.Vector4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(BackgroundRenderer.class)
public class MixinBackgroundRenderer {

    @Unique
    private static ConfigData getConfig() {
        return ConfigManager.getConfig();
    }

    @Inject(method = "applyFog", at = @At("RETURN"), cancellable = true)
    private static void onApplyFog(Camera camera, BackgroundRenderer.FogType fogType, Vector4f color, float viewDistance, boolean thickFog, float tickDelta, CallbackInfoReturnable<Fog> cir) {
        ConfigData config = getConfig();
        if (config == null || !config.customFog) return;

        Fog original = cir.getReturnValue();

        float start = original.start() * config.fogDistance;
        float end = original.end() * config.fogDistance * config.fogDensity;

        start = Math.max(0.0f, start);
        end = Math.max(start + 0.1f, end);

        float brightness = config.brightness;

        Fog modified = new Fog(
            start, end, original.shape(),
            original.red() * brightness,
            original.green() * brightness,
            original.blue() * brightness,
            original.alpha()
        );
        cir.setReturnValue(modified);
    }

    @Inject(method = "getFogColor", at = @At("RETURN"), cancellable = true)
    private static void onGetFogColor(Camera camera, float tickDelta, ClientWorld world, int skyColor, float rainGradient, CallbackInfoReturnable<Vector4f> cir) {
        ConfigData config = getConfig();
        if (config == null) return;

        Vector4f original = cir.getReturnValue();
        float r = original.x * config.brightness;
        float g = original.y * config.brightness;
        float b = original.z * config.brightness;
        cir.setReturnValue(new Vector4f(r, g, b, original.w));
    }
}
