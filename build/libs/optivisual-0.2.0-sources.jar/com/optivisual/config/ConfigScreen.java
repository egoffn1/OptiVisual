package com.optivisual.config;

import me.shedaniel.clothconfig2.api.ConfigBuilder;
import me.shedaniel.clothconfig2.api.ConfigCategory;
import me.shedaniel.clothconfig2.api.ConfigEntryBuilder;
import net.minecraft.class_2561;
import net.minecraft.class_437;

public class ConfigScreen {
    public static class_437 create(class_437 parent) {
        ConfigData config = ConfigManager.getConfig();
        ConfigBuilder builder = ConfigBuilder.create()
            .setParentScreen(parent)
            .setTitle(class_2561.method_43470("OptiVisual — Настройки"));

        ConfigEntryBuilder e = builder.entryBuilder();

        ConfigCategory visual = builder.getOrCreateCategory(class_2561.method_43470("Визуал"));

        visual.addEntry(e.startFloatField(class_2561.method_43470("Яркость"), config.brightness)
            .setDefaultValue(1.0f).setMin(0.1f).setMax(2.0f)
            .setTooltip(class_2561.method_43470("Общая яркость изображения (0.1–2.0)"))
            .setSaveConsumer(v -> { config.brightness = v; config.preset = "custom"; }).build());

        visual.addEntry(e.startFloatField(class_2561.method_43470("Контраст"), config.contrast)
            .setDefaultValue(1.0f).setMin(0.1f).setMax(2.0f)
            .setTooltip(class_2561.method_43470("Контрастность изображения"))
            .setSaveConsumer(v -> { config.contrast = v; config.preset = "custom"; }).build());

        visual.addEntry(e.startFloatField(class_2561.method_43470("Насыщенность"), config.saturation)
            .setDefaultValue(1.0f).setMin(0.0f).setMax(3.0f)
            .setTooltip(class_2561.method_43470("Насыщенность цветов"))
            .setSaveConsumer(v -> { config.saturation = v; config.preset = "custom"; }).build());

        visual.addEntry(e.startFloatField(class_2561.method_43470("Гамма"), config.gamma)
            .setDefaultValue(1.0f).setMin(0.1f).setMax(5.0f)
            .setTooltip(class_2561.method_43470("Гамма-коррекция"))
            .setSaveConsumer(v -> { config.gamma = v; config.preset = "custom"; }).build());

        visual.addEntry(e.startBooleanToggle(class_2561.method_43470("Сглаживание"), config.smoothLighting)
            .setDefaultValue(true)
            .setTooltip(class_2561.method_43470("Сглаженное освещение блоков"))
            .setSaveConsumer(v -> { config.smoothLighting = v; config.preset = "custom"; }).build());

        ConfigCategory fog = builder.getOrCreateCategory(class_2561.method_43470("Туман"));

        fog.addEntry(e.startBooleanToggle(class_2561.method_43470("Кастомный туман"), config.customFog)
            .setDefaultValue(false)
            .setTooltip(class_2561.method_43470("Включить свои настройки тумана"))
            .setSaveConsumer(v -> { config.customFog = v; config.preset = "custom"; }).build());

        fog.addEntry(e.startFloatField(class_2561.method_43470("Дальность тумана"), config.fogDistance)
            .setDefaultValue(0.7f).setMin(0.0f).setMax(3.0f)
            .setTooltip(class_2561.method_43470("Множитель дальности тумана"))
            .setSaveConsumer(v -> { config.fogDistance = v; config.preset = "custom"; }).build());

        fog.addEntry(e.startFloatField(class_2561.method_43470("Плотность тумана"), config.fogDensity)
            .setDefaultValue(1.0f).setMin(0.0f).setMax(3.0f)
            .setTooltip(class_2561.method_43470("Плотность тумана (выше = гуще)"))
            .setSaveConsumer(v -> { config.fogDensity = v; config.preset = "custom"; }).build());

        fog.addEntry(e.startBooleanToggle(class_2561.method_43470("Усиление цвета тумана"), config.fogColorBoost)
            .setDefaultValue(false)
            .setTooltip(class_2561.method_43470("Делает цвет тумана более насыщенным"))
            .setSaveConsumer(v -> { config.fogColorBoost = v; config.preset = "custom"; }).build());

        ConfigCategory sky = builder.getOrCreateCategory(class_2561.method_43470("Небо"));

        sky.addEntry(e.startBooleanToggle(class_2561.method_43470("Кастомное небо"), config.customSky)
            .setDefaultValue(false)
            .setTooltip(class_2561.method_43470("Включить свои настройки неба"))
            .setSaveConsumer(v -> { config.customSky = v; config.preset = "custom"; }).build());

        sky.addEntry(e.startFloatField(class_2561.method_43470("Яркость неба"), config.skyBrightness)
            .setDefaultValue(1.0f).setMin(0.1f).setMax(2.0f)
            .setTooltip(class_2561.method_43470("Яркость неба отдельно от общей"))
            .setSaveConsumer(v -> { config.skyBrightness = v; config.preset = "custom"; }).build());

        ConfigCategory culling = builder.getOrCreateCategory(class_2561.method_43470("Оптимизация рендера"));

        culling.addEntry(e.startBooleanToggle(class_2561.method_43470("Умный каллинг"), config.smartCulling)
            .setDefaultValue(true)
            .setTooltip(class_2561.method_43470("Не рендерить невидимые чанки"))
            .setSaveConsumer(v -> { config.smartCulling = v; config.preset = "custom"; }).build());

        culling.addEntry(e.startBooleanToggle(class_2561.method_43470("Каллинг сзади камеры"), config.behindCulling)
            .setDefaultValue(true)
            .setTooltip(class_2561.method_43470("Не рендерить чанки позади камеры"))
            .setSaveConsumer(v -> { config.behindCulling = v; config.preset = "custom"; }).build());

        culling.addEntry(e.startIntField(class_2561.method_43470("Дистанция LOD"), config.lodDistance)
            .setDefaultValue(64).setMin(16).setMax(256)
            .setTooltip(class_2561.method_43470("Расстояние до упрощённого рендера (в блоках)"))
            .setSaveConsumer(v -> { config.lodDistance = v; config.preset = "custom"; }).build());

        culling.addEntry(e.startBooleanToggle(class_2561.method_43470("Импостеры чанков"), config.chunkImpostors)
            .setDefaultValue(false)
            .setTooltip(class_2561.method_43470("Заменять дальние чанки на упрощённые картинки"))
            .setSaveConsumer(v -> { config.chunkImpostors = v; config.preset = "custom"; }).build());

        ConfigCategory perf = builder.getOrCreateCategory(class_2561.method_43470("Производительность"));

        perf.addEntry(e.startBooleanToggle(class_2561.method_43470("Авто-оптимизация"), config.autoOptimize)
            .setDefaultValue(true)
            .setTooltip(class_2561.method_43470("Автоматически подбирать настройки под железо"))
            .setSaveConsumer(v -> { config.autoOptimize = v; config.preset = "custom"; }).build());

        perf.addEntry(e.startIntField(class_2561.method_43470("Целевой FPS"), config.targetFPS)
            .setDefaultValue(60).setMin(15).setMax(999)
            .setTooltip(class_2561.method_43470("Целевое значение FPS для авто-настроек"))
            .setSaveConsumer(v -> { config.targetFPS = v; config.preset = "custom"; }).build());

        perf.addEntry(e.startBooleanToggle(class_2561.method_43470("Динам. дистанция рендера"), config.dynamicRenderDistance)
            .setDefaultValue(true)
            .setTooltip(class_2561.method_43470("Авто-подстройка дистанции прорисовки под FPS"))
            .setSaveConsumer(v -> { config.dynamicRenderDistance = v; config.preset = "custom"; }).build());

        perf.addEntry(e.startIntField(class_2561.method_43470("Мин. дистанция рендера"), config.minRenderDistance)
            .setDefaultValue(4).setMin(2).setMax(32)
            .setTooltip(class_2561.method_43470("Минимальная дистанция (в чанках)"))
            .setSaveConsumer(v -> { config.minRenderDistance = v; config.preset = "custom"; }).build());

        perf.addEntry(e.startIntField(class_2561.method_43470("Макс. дистанция рендера"), config.maxRenderDistance)
            .setDefaultValue(16).setMin(2).setMax(32)
            .setTooltip(class_2561.method_43470("Максимальная дистанция (в чанках)"))
            .setSaveConsumer(v -> { config.maxRenderDistance = v; config.preset = "custom"; }).build());

        perf.addEntry(e.startBooleanToggle(class_2561.method_43470("Показать FPS"), config.showFps)
            .setDefaultValue(false)
            .setTooltip(class_2561.method_43470("Показывать счётчик FPS на экране"))
            .setSaveConsumer(v -> { config.showFps = v; config.preset = "custom"; }).build());

        perf.addEntry(e.startBooleanToggle(class_2561.method_43470("Время прорисовки чанков"), config.showChunkRenderTime)
            .setDefaultValue(false)
            .setTooltip(class_2561.method_43470("Показывать время рендера чанков (мс)"))
            .setSaveConsumer(v -> { config.showChunkRenderTime = v; config.preset = "custom"; }).build());

        ConfigCategory presets = builder.getOrCreateCategory(class_2561.method_43470("Пресеты"));

        presets.addEntry(e.startSelector(
            class_2561.method_43470("Пресет качества"),
            new String[]{"low", "mid", "high", "ultra", "balanced", "custom"},
            config.preset
        ).setDefaultValue("balanced")
            .setTooltip(class_2561.method_43470("low — макс. FPS\nmid — сбалансированно\nhigh — красиво\nultra — максимальное качество\nbalanced — авто\ncustom — свои настройки"))
            .setSaveConsumer(v -> {
                ConfigManager.applyPreset(v);
            }).build());

        presets.addEntry(e.startTextDescription(
            class_2561.method_43470("Правый Shift — быстрое открытие меню")
        ).build());

        builder.setSavingRunnable(ConfigManager::save);

        return builder.build();
    }
}
