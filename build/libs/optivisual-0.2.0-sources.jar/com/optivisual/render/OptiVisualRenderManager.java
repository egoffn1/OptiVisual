package com.optivisual.render;

import com.optivisual.config.ConfigData;
import com.optivisual.config.ConfigManager;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_4184;

public class OptiVisualRenderManager {
    private static final class_310 client = class_310.method_1551();
    private static class_243 lastCameraPos = class_243.field_1353;
    private static class_243 cameraDirection = new class_243(0, 0, -1);
    private static boolean cameraReady = false;

    public static void updateCamera(class_4184 camera) {
        if (camera == null) return;
        lastCameraPos = camera.method_19326();
        float yaw = camera.method_19330();
        float pitch = camera.method_19329();
        double dirX = -Math.sin(Math.toRadians(yaw)) * Math.cos(Math.toRadians(pitch));
        double dirY = -Math.sin(Math.toRadians(pitch));
        double dirZ = Math.cos(Math.toRadians(yaw)) * Math.cos(Math.toRadians(pitch));
        cameraDirection = new class_243(dirX, dirY, dirZ);
        cameraReady = true;
    }

    public static class_243 getCameraPos() {
        return lastCameraPos;
    }

    public static class_243 getCameraDirection() {
        return cameraDirection;
    }

    public static boolean isBoxBehindCamera(class_238 box) {
        if (!cameraReady) return false;

        double cx = (box.field_1323 + box.field_1320) * 0.5;
        double cz = (box.field_1321 + box.field_1324) * 0.5;

        double dx = cx - lastCameraPos.field_1352;
        double dz = cz - lastCameraPos.field_1350;

        double dot = dx * cameraDirection.field_1352 + dz * cameraDirection.field_1350;

        return dot < -8.0;
    }

    public static float getDistanceToChunk(int chunkX, int chunkZ) {
        double dx = (chunkX * 16 + 8) - lastCameraPos.field_1352;
        double dz = (chunkZ * 16 + 8) - lastCameraPos.field_1350;
        return (float) Math.sqrt(dx * dx + dz * dz);
    }
}
