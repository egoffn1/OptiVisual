package com.optivisual.render;

import com.optivisual.config.ConfigData;
import com.optivisual.config.ConfigManager;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_9779;

public class HudOverlay implements HudRenderCallback {

    @Override
    public void onHudRender(class_332 drawContext, class_9779 renderTickCounter) {
        class_310 client = class_310.method_1551();
        if (client.field_1687 == null) return;

        ConfigData config = ConfigManager.getConfig();
        if (config == null) return;

        class_327 textRenderer = client.field_1772;
        int y = 4;

        if (config.showFps) {
            float fps = PerformanceMonitor.getSmoothFPS();
            String fpsText = String.format("FPS: %.0f", fps);
            int color = fps >= 60 ? 0xFF55FF55 : fps >= 30 ? 0xFFFFFF55 : 0xFFFF5555;
            drawContext.method_51433(textRenderer, fpsText, 4, y, color, true);
            y += 10;
        }

        if (config.showChunkRenderTime) {
            float ms = PerformanceMonitor.getLastChunkRenderTimeMs();
            String chunkText = String.format("Чанки: %.1f ms", ms);
            int color = ms < 5.0f ? 0xFF55FF55 : ms < 15.0f ? 0xFFFFFF55 : 0xFFFF5555;
            drawContext.method_51433(textRenderer, chunkText, 4, y, color, true);
            y += 10;
        }
    }
}
