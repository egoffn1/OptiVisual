package com.optivisual.mixins;

import com.optivisual.config.ConfigManager;
import com.optivisual.config.ConfigData;
import com.optivisual.render.OptiVisualRenderManager;
import com.optivisual.render.PerformanceMonitor;
import net.minecraft.class_310;
import net.minecraft.class_3695;
import net.minecraft.class_4184;
import net.minecraft.class_4604;
import net.minecraft.class_761;
import net.minecraft.class_9779;
import net.minecraft.class_9909;
import net.minecraft.class_9958;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_761.class)
public class MixinWorldRenderer {

    @Unique
    private long optiVisual$renderStartTime = 0L;
    @Unique
    private int optiVisual$frameCount = 0;

    @Inject(method = "renderMain", at = @At("HEAD"))
    private void onRenderMainStart(class_9909 frameGraphBuilder, class_4604 frustum, class_4184 camera, Matrix4f positionMatrix, Matrix4f projectionMatrix, class_9958 fog, boolean renderBlockOutline, boolean renderEntityOutlines, class_9779 renderTickCounter, class_3695 profiler, CallbackInfo ci) {
        if (class_310.method_1551().field_1687 == null) return;

        OptiVisualRenderManager.updateCamera(camera);
        PerformanceMonitor.tick();

        ConfigData config = ConfigManager.getConfig();
        if (config != null && config.showChunkRenderTime) {
            optiVisual$renderStartTime = System.nanoTime();
        }
    }

    @Inject(method = "renderMain", at = @At("RETURN"))
    private void onRenderMainEnd(class_9909 frameGraphBuilder, class_4604 frustum, class_4184 camera, Matrix4f positionMatrix, Matrix4f projectionMatrix, class_9958 fog, boolean renderBlockOutline, boolean renderEntityOutlines, class_9779 renderTickCounter, class_3695 profiler, CallbackInfo ci) {
        if (optiVisual$renderStartTime == 0L) return;

        long elapsed = System.nanoTime() - optiVisual$renderStartTime;
        optiVisual$renderStartTime = 0L;
        optiVisual$frameCount++;

        if (optiVisual$frameCount % 30 == 0) {
            PerformanceMonitor.setLastChunkRenderTimeMs(elapsed / 1_000_000.0f);
        }
    }
}
