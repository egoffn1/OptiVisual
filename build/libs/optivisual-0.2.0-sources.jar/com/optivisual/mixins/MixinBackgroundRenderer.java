package com.optivisual.mixins;

import com.optivisual.config.ConfigManager;
import net.minecraft.class_310;
import net.minecraft.class_4184;
import net.minecraft.class_638;
import net.minecraft.class_758;
import net.minecraft.class_9958;
import com.optivisual.config.ConfigData;
import org.joml.Vector4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_758.class)
public class MixinBackgroundRenderer {

    @Unique
    private static ConfigData lastConfig = null;
    @Unique
    private static class_9958 cachedFog = null;
    @Unique
    private static Vector4f cachedFogColor = null;
    @Unique
    private static int cachedFogFlags = 0;
    @Unique
    private static int cachedColorFlags = 0;

    @Unique
    private static float clamp(float v) {
        return Math.max(0.0f, Math.min(1.0f, v));
    }

    @Inject(method = "applyFog", at = @At("RETURN"), cancellable = true)
    private static void onApplyFog(class_4184 camera, class_758.class_4596 fogType, Vector4f color, float viewDistance, boolean thickFog, float tickDelta, CallbackInfoReturnable<class_9958> cir) {
        if (class_310.method_1551().field_1687 == null) return;
        ConfigData config = ConfigManager.getConfig();
        if (config == null || !config.customFog) return;

        int flags = Float.floatToIntBits(config.fogDistance) ^ Float.floatToIntBits(config.fogDensity) ^
                    (config.fogColorBoost ? 1 : 0) ^ Float.floatToIntBits(config.brightness);
        if (config == lastConfig && cachedFog != null && flags == cachedFogFlags) {
            cir.setReturnValue(cachedFog);
            return;
        }

        class_9958 original = cir.getReturnValue();

        float start = original.comp_3009() * config.fogDistance;
        float end = original.comp_3010() * config.fogDistance * config.fogDensity;

        start = Math.max(0.0f, start);
        end = Math.max(start + 0.1f, end);

        float bright = config.fogColorBoost ? config.brightness : 1.0f;

        cachedFog = new class_9958(
            start, end, original.comp_3011(),
            clamp(original.comp_3012() * bright),
            clamp(original.comp_3013() * bright),
            clamp(original.comp_3014() * bright),
            clamp(original.comp_3015())
        );
        cachedFogFlags = flags;
        lastConfig = config;
        cir.setReturnValue(cachedFog);
    }

    @Inject(method = "getFogColor", at = @At("RETURN"), cancellable = true)
    private static void onGetFogColor(class_4184 camera, float tickDelta, class_638 world, int skyColor, float rainGradient, CallbackInfoReturnable<Vector4f> cir) {
        if (class_310.method_1551().field_1687 == null) return;
        ConfigData config = ConfigManager.getConfig();
        if (config == null || !config.customFog) return;

        int flags = (config.fogColorBoost ? 1 : 0) ^ Float.floatToIntBits(config.brightness);
        if (config == lastConfig && cachedFogColor != null && flags == cachedColorFlags) {
            cir.setReturnValue(cachedFogColor);
            return;
        }

        Vector4f original = cir.getReturnValue();
        float bright = config.fogColorBoost ? config.brightness : 1.0f;
        cachedFogColor = new Vector4f(
            clamp(original.x * bright),
            clamp(original.y * bright),
            clamp(original.z * bright),
            clamp(original.w)
        );
        cachedColorFlags = flags;
        lastConfig = config;
        cir.setReturnValue(cachedFogColor);
    }
}
