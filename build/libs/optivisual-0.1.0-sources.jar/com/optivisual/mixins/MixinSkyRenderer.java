package com.optivisual.mixins;

import com.optivisual.config.ConfigManager;
import net.minecraft.class_9975;
import com.optivisual.config.ConfigData;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_9975.class)
public class MixinSkyRenderer {

    @Inject(method = "renderTopSky", at = @At("HEAD"))
    private void onRenderTopSky(float red, float green, float blue, CallbackInfo ci) {
        ConfigData config = ConfigManager.getConfig();
        if (config == null) return;
    }

    @Inject(method = "renderSkyDark", at = @At("HEAD"))
    private void onRenderSkyDark(CallbackInfo ci) {
        ConfigData config = ConfigManager.getConfig();
        if (config == null) return;
    }
}
