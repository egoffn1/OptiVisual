package com.optivisual.mixins;

import com.optivisual.config.ConfigManager;
import net.minecraft.class_4184;
import net.minecraft.class_638;
import net.minecraft.class_758;
import net.minecraft.class_9958;
import com.optivisual.config.ConfigData;
import org.joml.Vector4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_758.class)
public class MixinBackgroundRenderer {

    @Unique
    private static ConfigData getConfig() {
        return ConfigManager.getConfig();
    }

    @Inject(method = "applyFog", at = @At("RETURN"), cancellable = true)
    private static void onApplyFog(class_4184 camera, class_758.class_4596 fogType, Vector4f color, float viewDistance, boolean thickFog, float tickDelta, CallbackInfoReturnable<class_9958> cir) {
        ConfigData config = getConfig();
        if (config == null || !config.customFog) return;

        class_9958 original = cir.getReturnValue();

        float start = original.comp_3009() * config.fogDistance;
        float end = original.comp_3010() * config.fogDistance * config.fogDensity;

        start = Math.max(0.0f, start);
        end = Math.max(start + 0.1f, end);

        float brightness = config.brightness;

        class_9958 modified = new class_9958(
            start, end, original.comp_3011(),
            original.comp_3012() * brightness,
            original.comp_3013() * brightness,
            original.comp_3014() * brightness,
            original.comp_3015()
        );
        cir.setReturnValue(modified);
    }

    @Inject(method = "getFogColor", at = @At("RETURN"), cancellable = true)
    private static void onGetFogColor(class_4184 camera, float tickDelta, class_638 world, int skyColor, float rainGradient, CallbackInfoReturnable<Vector4f> cir) {
        ConfigData config = getConfig();
        if (config == null) return;

        Vector4f original = cir.getReturnValue();
        float r = original.x * config.brightness;
        float g = original.y * config.brightness;
        float b = original.z * config.brightness;
        cir.setReturnValue(new Vector4f(r, g, b, original.w));
    }
}
