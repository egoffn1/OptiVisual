package com.optivisual.util;

import com.optivisual.config.ConfigManager;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL20;

public class HardwareDetector {
    private static String gpuInfo = "unknown";
    private static String gpuVendor = "unknown";
    private static int gpuMemoryMB = -1;
    private static int cpuCores = 0;
    private static boolean detected = false;

    public static void detect() {
        if (detected) return;

        try {
            gpuInfo = GL11.glGetString(GL11.GL_RENDERER);
            gpuVendor = GL11.glGetString(GL11.GL_VENDOR);
            String version = GL11.glGetString(GL11.GL_VERSION);
            cpuCores = Runtime.getRuntime().availableProcessors();

            int[] maxTextureSize = new int[1];
            GL11.glGetIntegerv(GL11.GL_MAX_TEXTURE_SIZE, maxTextureSize);

            detected = true;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static String getGpuInfo() {
        return gpuInfo;
    }

    public static String getGpuVendor() {
        return gpuVendor;
    }

    public static int getCpuCores() {
        return cpuCores;
    }

    public static boolean isLowEndGPU() {
        detect();
        String gpu = gpuInfo.toLowerCase();
        String vendor = gpuVendor.toLowerCase();

        if (vendor.contains("intel") && !vendor.contains("arc")) return true;
        if (gpu.contains("gt") || gpu.contains("gtx 10") || gpu.contains("gtx 9")) return true;
        if (gpu.contains("hd graphics") || gpu.contains("uhd graphics")) return true;
        if (gpu.contains("radeon") && (gpu.contains("r5") || gpu.contains("r7") || gpu.contains("hd 7") || gpu.contains("vega")) && !gpu.contains("rx")) return true;

        return false;
    }

    public static boolean isMidRangeGPU() {
        detect();
        String gpu = gpuInfo.toLowerCase();
        String vendor = gpuVendor.toLowerCase();

        if (gpu.contains("gtx 16") || gpu.contains("rtx 20") || gpu.contains("gtx 1070") || gpu.contains("gtx 1080")) return true;
        if (gpu.contains("rx 5") || gpu.contains("rx 5") || gpu.contains("rx 6")) return true;
        if (gpu.contains("arc")) return true;

        return false;
    }

    public static boolean isHighEndGPU() {
        detect();
        String gpu = gpuInfo.toLowerCase();

        if (gpu.contains("rtx 30") || gpu.contains("rtx 40") || gpu.contains("rtx 50")) return true;
        if (gpu.contains("rx 6") && (gpu.contains("xt") || gpu.contains("6900") || gpu.contains("6800"))) return true;
        if (gpu.contains("rx 7")) return true;
        if (gpu.contains("pro") && gpu.contains("w")) return true;

        return false;
    }

    public static String suggestPreset() {
        detect();

        if (isHighEndGPU()) return "ultra";
        if (isMidRangeGPU()) return "high";
        if (isLowEndGPU()) return "low";

        if (cpuCores <= 4) return "low";
        if (cpuCores <= 6) return "mid";

        return "balanced";
    }

    public static void applyAutoConfig() {
        String preset = suggestPreset();
        ConfigManager.applyPreset(preset);
    }
}
