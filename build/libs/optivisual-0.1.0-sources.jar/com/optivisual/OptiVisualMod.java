package com.optivisual;

import com.optivisual.commands.CommandRegistry;
import com.optivisual.config.ConfigManager;
import net.fabricmc.api.ClientModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class OptiVisualMod implements ClientModInitializer {
    public static final String MOD_ID = "optivisual";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitializeClient() {
        LOGGER.info("OptiVisualMod загружен!");
        ConfigManager.init();
        CommandRegistry.registerCommands();
    }
}
