package com.optivisual.config;

public class ConfigData {
    public float brightness = 1.0f;
    public float contrast = 1.0f;
    public float saturation = 1.0f;
    public float gamma = 1.0f;
    public float fogDistance = 0.7f;
    public float fogDensity = 1.0f;
    public int skyColorRed = 255;
    public int skyColorGreen = 220;
    public int skyColorBlue = 180;
    public boolean customSkyColor = false;
    public String preset = "balanced";
    public boolean autoOptimize = true;
    public int targetFPS = 60;
    public float renderDistanceScale = 1.0f;
    public boolean smoothLighting = true;
    public boolean customFog = false;
}
